#importing of information needed
import csv
import random
import time
def _login_():
  #defined varibles
  uscore1 = 0
  uscore2 = 0
  count = 0
  found1 = False 
  found2 = False
  #letting a loop to makesure that one user atleast is incorrect
  while found1 == False or found2 == False:
    #input users
    User1 = input ("Username for player 1:")
    Pass1 = input ("Password for player 1:")
    found1 = False
    #opening files password.txt and username.txt
    username = open("username.txt","r")
    password = open("password.txt","r")
    #reading the files
    usernamelines = username.readlines()
    passwordlines = password.readlines()
    #searches to see if password is equal to password
    for i in range(len(usernamelines)):
      if User1 == (usernamelines[i].strip('\n')) and Pass1 == (passwordlines[i].strip('\n')):
        found1 = True
    #inputs user and password 
    User2 = input ("Username for player 2:")
    Pass2 = input ("Password for player 2:")
    found2 = False
    #opens file
    username = open("username.txt","r")
    password = open("password.txt","r")
    #reads file
    usernamelines = username.readlines()
    passwordlines = password.readlines()
    #searches to check username and passwords are right
    for i in range(len(usernamelines)):
      if User2 == (usernamelines[i].strip('\n')) and Pass2 == (passwordlines[i].strip('\n')):
        found2 = True
      #validation to check passwords
    if User1 == User2:
      print("Sorry used the same usernames for both")
      found1 = False
      found2 = False
    elif found1 == True and found2 == True:
          _rounds_( User1, User2, Pass1, Pass2, uscore1, uscore2)
    elif found2 == True:
      print ("Sorry login details not accepted for player 1. Please try again.")
    elif found1 == True:
      print ("Sorry login details not accepted for player 2. Please try again.")
    else:
      print ("Sorry login details not accepted for both username. Please try again.")
    count = count + 1
    if count ==4:
      print ("Sorry unable to keep going as unfound credentials 4 times.")
      exit()
  
    
def _player1_(Uscore1):
  #player1 scoreing 
  print ("Player 1:")
  score = __roll__()
  Uscore1 = Uscore1 + score
  #check above 0
  if Uscore1 <= 0:
      Uscore1 = 0
  return Uscore1

def _player2_(Uscore2):
  # player 2 scoring
  print ("Player 2:")
  score = __roll__()
  Uscore2 = Uscore2 + score
  #check above 0
  if Uscore2 <= 0:
    Uscore2 = 0
  return Uscore2

def __roll__():
  #varbles set
  score = 0
  playerextra = 0
  player = [1,2,3,4]

  #rolls twice
  for i in range (0,2,1):
    input("And your roll is:")
    player[i]= random.randrange(1,6)
    print("You rolled a", player[i], "!")

 #allows extra roll if doubles
  if player[0] == player[1]:
    print("You rolled a double so an extra roll")
    input("And your roll is:")
    playerextra= random.randrange(1,6)
    print("You rolled a", playerextra, "!")
  
  player1 = player[0] + player[1] + playerextra
  e = [2,4,6,8,10,12]
  #score is added
  if player1 in e:
    score = score + 10 + player1
  else:
    score = score - 5
  print ("Your score this round is", score, "!")
  #scor is returned to player
  return score
 
def _clear_():
  #waits 1.5 seconds
  time.sleep(1.5)
  import os
  #clears screen
  os.system('clear')
  return

def _rounds_(User1, User2, Pass1, Pass2, uscore1, uscore2):
  #declared varibles
  Uscore1 = 0
  Uscore2 = 0
  # allows 5 rounds
  for i in range (1,6, 1):
    _clear_()
    print ("Round", i, ":")
    Uscore1 = _player1_(Uscore1)
    print ("Player 1 score after the round is ", Uscore1)
    Uscore2=_player2_(Uscore2)
    print ("Player 1 score after the round is ", Uscore2)
  #sees if scores are the same
  while Uscore1 == Uscore2:
    _clear_()
    #lets both to roll
    print("Player 1 score:", Uscore1)
    print("Player 2 score:", Uscore2)
    print("Sudden death:")
    Uscore1=_player1_(Uscore1)
    Uscore2=_player2_(Uscore2)
    print("Player 1 score:", Uscore1)
    print("Player 2 score:", Uscore2)
    #checking who wins
  if Uscore1 > Uscore2:
    print("Player 1 wins!")
    highscore= Uscore1
    user = User1
  elif Uscore1 < Uscore2:
    print("Player 2 wins!")
    highscore= Uscore2
    user = User2
  else:
    print("ERROR!")
    _rounds_(User1, User2, Pass1, Pass2, uscore1, uscore2)
  _HS_(user, highscore)

def _HS_(user, highscore):
  #opens file saves new score
  with open ('score.csv', 'a', newline='') as CSVSCORES:
    write = csv.writer(CSVSCORES, delimiter=',')
    write.writerow([user,highscore])
  CSVSCORES.close()
  _sort_()

def _sort_():
  #opens file
  score2=[]
  csv_HS = open('score.csv', 'r')
  HSData = csv.reader(csv_HS, delimiter=',')
  scores = []
  #varible list set for scores and score2
  for row in HSData:
    scoretoadd = row[1] + " - " + row [0]
    score=row[1]
    score2.append(scoretoadd)
    scores.append(score)
  for row in HSData:
    scoretoadd = row[1] + " - " + row [0]
    score2.append(scoretoadd)
  #bubble sort
  n = len(scores)
  swapped = True
  while n > 0 and swapped == True:
    swapped = False
    n = n - 1
    for i in range(0,n,1):
      p = i+ 1
      if int(scores[i]) < int(scores[i+1]):
        temp = scores[i]
        scores[i] = scores[n]
        scores[n] = temp
        swapped = True 
  high=score2
  #searches person who worked
  for n in range (0,len(scores),1):
    for i in range (0, len(score2),1):
      x = str(scores[n]) in str(score2[i])
      if x == True:
        high[n]= score2[i]
        break
  #lists highscores
  print("The 5 biggest numbers are:")
  if len(scores) <5:
    for i in range (0,len(high),1):
      print(high[i])
  else:    
    for i in range (0,5,1):
      print(high[i])
    

_login_()