count = 0
found1 = False 
found2 = False
while found1 == False or found2 == False:
  User1 = input ("Username for player 1:")
  Pass1 = input ("Password for player 1:")
  found1 = False
  username = open("username.txt","r")
  password = open("password.txt","r")
  usernamelines = username.readlines()
  passwordlines = password.readlines()
  for i in range(0, 6, 1):
    if User1 == (usernamelines[i].strip('\n')) and Pass1 == (passwordlines[i].strip('\n')):
      print("yay")
      found1 = True

  User2 = input ("Username for player 2:")
  Pass2 = input ("Password for player 2:")
  found2 = False
  username = open("username.txt","r")
  password = open("password.txt","r")
  usernamelines = username.readlines()
  passwordlines = password.readlines()
  for i in range(0, 6, 1):
    if User2 == (usernamelines[i].strip('\n')) and Pass2 == (passwordlines[i].strip('\n')):
      print("yay")
      found2 = True
    #found1 = False
    
if User1 == User2:
    print("Sorry used the same usernames for both")
    found1 = False
    found2 = False
elif found1 == True and found2 == True:
      #_rounds_( User1, User2, Pass1, Pass2, uscore1, uscore2)
  print("sorted")
elif found2 == True:
  print ("Sorry login details not accepted for player 1. Please try again.")
    # _login_(pas)
elif found1 == True:
  print ("Sorry login details not accepted for player 2. Please try again.")
    # _login_(pas)
else:
  print ("Sorry login details not accepted for both username. Please try again.")

  count = count + 1
  if count ==4:
    print ("Sorry unable to keep going as unfound credentials 4 times.")
    exit()
