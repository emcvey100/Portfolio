def reads():
    fil=open("freinds.txt", "r")
    print(fil.read())
    fil.close()

def save(name, telephone):
    file=open("freinds.txt", "a")
    name=name+":"
    file.write(name)
    file.write(telephone)
    file.write("\n")
    file.close()



want= True
while want==True:
    fr=input("Name:")
    num=input("Number:")
    save(fr,num)
    inp=input("Do you want to save again, y/n").upper()
    if inp!="YES" and inp!="Y":
        want=False
reads()
